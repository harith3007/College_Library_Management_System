void options( );
int admin( );
int student( );
void menu_librarian( );
void menu_student( );
void clear();
void add_record();
void display( );
void search( );
void Delete( );
void Add_student( );
void Display_student( );
void Search_student( );
void Delete_student( );
void Issue_book( );
void Display_books();
void New_User();

